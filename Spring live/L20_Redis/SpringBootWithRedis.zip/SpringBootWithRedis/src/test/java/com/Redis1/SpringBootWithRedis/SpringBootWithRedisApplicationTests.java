package com.Redis1.SpringBootWithRedis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWithRedisApplicationTests {

	@Test
	void contextLoads() {
	}

}
