package com.pdm.Redis_SB_Mysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedisSbMysqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(RedisSbMysqlApplication.class, args);
	}

}
