package com.gfg_JBDL65.Microservicess;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicessApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicessApplication.class, args);
	}

}
