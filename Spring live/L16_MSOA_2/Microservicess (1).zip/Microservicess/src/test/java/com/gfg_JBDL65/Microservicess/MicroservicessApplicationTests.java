package com.gfg_JBDL65.Microservicess;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicessApplicationTests {

	@Test
	void contextLoads() {
	}

}
