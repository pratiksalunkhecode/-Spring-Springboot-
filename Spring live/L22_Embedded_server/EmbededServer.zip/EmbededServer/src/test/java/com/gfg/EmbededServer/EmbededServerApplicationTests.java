package com.gfg.EmbededServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmbededServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
