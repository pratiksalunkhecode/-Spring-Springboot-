package com.gfg.L13_Hibernate_Intro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class L13HibernateIntroApplication {

	public static void main(String[] args) {
		SpringApplication.run(L13HibernateIntroApplication.class, args);
	}

}
