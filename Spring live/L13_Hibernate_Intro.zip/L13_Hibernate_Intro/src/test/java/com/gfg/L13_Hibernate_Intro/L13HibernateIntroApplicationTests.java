package com.gfg.L13_Hibernate_Intro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class L13HibernateIntroApplicationTests {

	@Test
	void contextLoads() {
	}

}
