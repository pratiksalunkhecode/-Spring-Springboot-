package com.gfg_jbdl65.Hibernate_Mappings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateMappingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
