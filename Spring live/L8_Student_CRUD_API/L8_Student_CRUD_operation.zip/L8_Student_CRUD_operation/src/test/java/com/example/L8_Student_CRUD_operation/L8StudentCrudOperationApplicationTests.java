package com.example.L8_Student_CRUD_operation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class L8StudentCrudOperationApplicationTests {

	@Test
	void contextLoads() {
	}

}
